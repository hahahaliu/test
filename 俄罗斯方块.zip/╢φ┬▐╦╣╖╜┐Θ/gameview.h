#ifndef GAMEVIEW_H
#define GAMEVIEW_H

#include <QFrame>
#include <QWidget>



QT_BEGIN_NAMESPACE
class QLCDNumber;
class QLabel;
class QPushButton;
QT_END_NAMESPACE
class TetrixBoard;


class gameView : public QWidget
{
    Q_OBJECT

public:
    gameView();

private:
    QLabel *createLabel(const QString &text);
    //游戏框架组件
    TetrixBoard *board;
    //标签
    QLabel *nextPieceLabel;
    //3个LCD数字显示框
    QLCDNumber *scoreLcd;
    QLCDNumber *levelLcd;
    QLCDNumber *linesLcd;
    //3个按钮
    QPushButton *startButton;
    QPushButton *quitButton;
    QPushButton *pauseButton;
};


#endif
