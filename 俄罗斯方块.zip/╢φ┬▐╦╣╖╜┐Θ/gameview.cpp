#include <QtWidgets>
#include <QIcon>
#include "board.h"
#include "gameview.h"


gameView::gameView()
{
    QPalette palette;
    this->setAutoFillBackground(true);
    palette.setBrush(QPalette::Background,QPixmap(":/background.png"));
    this->setPalette(palette);
    resize(550, 370);
    board = new TetrixBoard;

    nextPieceLabel = new QLabel;
    nextPieceLabel->setFrameStyle(QFrame::Box | QFrame::Raised);//设置框架为凸起的小盒子式
    nextPieceLabel->setAlignment(Qt::AlignCenter);
    board->setNextPieceLabel(nextPieceLabel);

    scoreLcd = new QLCDNumber(5);//分数显示5位数
    scoreLcd->setSegmentStyle(QLCDNumber::Filled);

    levelLcd = new QLCDNumber(2);//等级显示2位数
    levelLcd->setSegmentStyle(QLCDNumber::Filled);
    linesLcd = new QLCDNumber(5);//行数显示为5位数
    linesLcd->setSegmentStyle(QLCDNumber::Filled);

    //按钮与焦点的设置，全不设置焦点
    startButton = new QPushButton(tr("&开始"));
    startButton->setFocusPolicy(Qt::NoFocus);
    quitButton = new QPushButton(tr("&退出"));
    quitButton->setFocusPolicy(Qt::NoFocus);
    pauseButton = new QPushButton(tr("&暂停"));
    pauseButton->setFocusPolicy(Qt::NoFocus);
    //将信号与槽连接
    connect(startButton, SIGNAL(clicked()), board, SLOT(start()));
    connect(quitButton , SIGNAL(clicked()), qApp, SLOT(quit()));
    connect(pauseButton, SIGNAL(clicked()), board, SLOT(pause()));
    connect(board, SIGNAL(scoreChanged(int)), scoreLcd, SLOT(display(int)));
    connect(board, SIGNAL(levelChanged(int)), levelLcd, SLOT(display(int)));
    connect(board, SIGNAL(linesRemovedChanged(int)),
            linesLcd, SLOT(display(int)));

    //addWidget(QWidget*,int row,int column,int rowStretch,int columnStretch,Qt::Alignment),
    //row表示行，column表示列，rowStretch表示行方向占据的宽度，columnStretch表示列方向占的宽度，Qt::Alignment表示对齐方式，默认为0
    //进行布局
    QGridLayout *layout = new QGridLayout;
    layout->addWidget(createLabel(tr("下一个")), 0, 1);
    layout->addWidget(nextPieceLabel, 1, 1);
    layout->addWidget(createLabel(tr("级别")), 2, 1);
    layout->addWidget(levelLcd, 3, 1);
    layout->addWidget(startButton, 4, 1);
    layout->addWidget(board, 0, 0, 6, 1);
    layout->addWidget(createLabel(tr("分数")), 0, 2);
    layout->addWidget(scoreLcd, 1, 2);
    layout->addWidget(createLabel(tr("已满行数")), 2, 2);
    layout->addWidget(createLabel(tr("  \n   \n   \n   \n  \n \n")),5,1);
    layout->addWidget(linesLcd, 3, 2);
    layout->addWidget(quitButton, 4, 2);
    layout->addWidget(pauseButton, 5, 2);
    setLayout(layout);

    setWindowTitle(tr("我的俄罗斯方块"));
    setWindowIcon(QIcon(":/box.gif"));


}
//重写一个创建新标签的函数
QLabel *gameView::createLabel(const QString &text)
{
    QLabel *lbl = new QLabel(text);
    //设置对齐方式为中心对齐或者下平齐
    lbl->setAlignment(Qt::AlignHCenter | Qt::AlignBottom);
    return lbl;
}

