#include <QtWidgets>

#include "board.h"

TetrixBoard::TetrixBoard(QWidget *parent)
    : QFrame(parent)
{


    setFrameStyle(QFrame::Panel | QFrame::Sunken);//陷入式的控制板
    setFocusPolicy(Qt::StrongFocus);//设置关注焦点
    isStarted = false;//初始化游戏未开始
    isPaused = false;//初始游戏未暂停
    clearBoard();//初始化该区域清空

    nextPiece.setRandomShape();//设置下一个随机的形状
}


void TetrixBoard::setNextPieceLabel(QLabel *label){//设置这个标签的名字
    nextPieceLabel = label;
}

QSize TetrixBoard::sizeHint() const{
    return QSize(BoardWidth * 15 + frameWidth() * 2,
                 BoardHeight * 15 + frameWidth() * 2);
}

QSize TetrixBoard::minimumSizeHint() const{
    return QSize(BoardWidth * 5 + frameWidth() * 2,
                 BoardHeight * 5 + frameWidth() * 2);
}
//游戏开始，伴随着游戏的初始化，状态判断，数据的显示，计时器的启用与新的方块的建立
void TetrixBoard::start(){
    if (isPaused)
        return;

    isStarted = true;
    isWaitingAfterLine = false;
    numLinesRemoved = 0;
    numPiecesDropped = 0;
    score = 0;
    level = 1;
    clearBoard();

    emit linesRemovedChanged(numLinesRemoved);
    emit scoreChanged(score);
    emit levelChanged(level);

    newPiece();
    timer.start(timeoutTime(), this);
}
//游戏暂停的设定伴随状态的改变，计时器的停止
void TetrixBoard::pause(){
    if (!isStarted)
        return;

    isPaused = !isPaused;
    if (isPaused) {
        timer.stop();
    } else {
        timer.start(timeoutTime(), this);
    }
    update();

}


//游戏框的绘制时间处理函数
void TetrixBoard::paintEvent(QPaintEvent *event){
    QFrame::paintEvent(event);

    QPainter painter(this);
    QRect rect = contentsRect();//建立一个框架内部的矩形
    //在游戏框中设置背景图片
    painter.drawPixmap(3,3,squareWidth()*12-3,squareHeight()*25-3,QPixmap(":/background1.png"));
    if (isPaused) {//若游戏为暂停状态，在游戏框内重绘一个内嵌矩形并且在中央显示“暂停”
        painter.drawText(rect, Qt::AlignCenter, tr("暂停"));
        return;
    }

    //设定游戏框（显示方块移动的范围）的高度
    int boardTop = rect.bottom() - BoardHeight*squareHeight();

    for (int i = 0; i < BoardHeight; ++i) {
        for (int j = 0; j < BoardWidth; ++j) {
            TetrixShape shape = shapeAt(j, BoardHeight - i - 1);
            if (shape != NoShape)
                drawSquare(painter, rect.left() + j * squareWidth(),
                           boardTop + i * squareHeight(), shape);
        }

    }

    if (curPiece.shape() != NoShape) {
        for (int i = 0; i < 4; ++i) {
            int x = curX + curPiece.x(i);
            int y = curY - curPiece.y(i);
            drawSquare(painter, rect.left() + x * squareWidth(),
                       boardTop + (BoardHeight - y - 1) * squareHeight(),
                       curPiece.shape());
        }

    }

}


//设定各种键盘触发事件的处理函数
void TetrixBoard::keyPressEvent(QKeyEvent *event)
{
    if (!isStarted || isPaused || curPiece.shape() == NoShape) {
        QFrame::keyPressEvent(event);
        return;
    }

    switch (event->key()) {
    case Qt::Key_Left://键盘向左，使方块左移
        tryMove(curPiece, curX - 1, curY);
        break;
    case Qt::Key_Right://键盘向右，使方块右移
        tryMove(curPiece, curX + 1, curY);
        break;
    case Qt::Key_Down://键盘向下，使方块顺时针旋转
        tryMove(curPiece.rotatedRight(), curX, curY);
        break;
    case Qt::Key_Up://键盘向上，使方块逆时针旋转
        tryMove(curPiece.rotatedLeft(), curX, curY);
        break;
    case Qt::Key_Space://空格键，使方块坠落
        dropDown();
        break;
    case Qt::Key_D://D键使方块加速下降一行
        oneLineDown();
        break;
    default:
        QFrame::keyPressEvent(event);
    }

}

//计时器的事件处理
void TetrixBoard::timerEvent(QTimerEvent *event)
{
    if (event->timerId() == timer.timerId()) {
        if (isWaitingAfterLine) {
            isWaitingAfterLine = false;
            newPiece();
            timer.start(timeoutTime(), this);
        } else {
            oneLineDown();
        }
    } else {
        QFrame::timerEvent(event);
    }
}


//清除游戏框内的图形
void TetrixBoard::clearBoard()
{
    for (int i = 0; i < BoardHeight * BoardWidth; ++i)
        board[i] = NoShape;
}
//方块坠落的函数
void TetrixBoard::dropDown()
{
    int dropHeight = 0;
    int newY = curY;
    while (newY > 0) {
        if (!tryMove(curPiece, curX, newY - 1))
            break;
        --newY;
        ++dropHeight;
    }
    pieceDropped(dropHeight);

}

void TetrixBoard::oneLineDown()
{
    if (!tryMove(curPiece, curX, curY - 1))
        pieceDropped(0);
}

void TetrixBoard::pieceDropped(int dropHeight)
{//方块下落完毕
    for (int i = 0; i < 4; ++i) {
        int x = curX + curPiece.x(i);
        int y = curY - curPiece.y(i);
        shapeAt(x, y) = curPiece.shape();
    }

    ++numPiecesDropped;
    if (numPiecesDropped % 25 == 0) {
        ++level;
        timer.start(timeoutTime(), this);
        emit levelChanged(level);
    }


    removeFullLines();

    if (!isWaitingAfterLine)
        newPiece();

}



void TetrixBoard::removeFullLines()
{//设定默认满行数为0
    int numFullLines = 0;
    //若
    for (int i = BoardHeight - 1; i >= 0; --i) {
        bool lineIsFull = true;

        for (int j = 0; j < BoardWidth; ++j) {
            if (shapeAt(j, i) == NoShape) {
                lineIsFull = false;
                break;
            }
        }
        //若仍有满行则增加满行的个数，同时销毁掉这些行数，将其上的各行下移
        if (lineIsFull) {

            ++numFullLines;
            for (int k = i; k < BoardHeight - 1; ++k) {
                for (int j = 0; j < BoardWidth; ++j)
                    shapeAt(j, k) = shapeAt(j, k + 1);
            }

            for (int j = 0; j < BoardWidth; ++j)
                shapeAt(j, BoardHeight - 1) = NoShape;
        }

    }

    //每消去一行分数加上10
    if (numFullLines > 0) {
        numLinesRemoved += numFullLines;
        score += 10 * numFullLines;
        emit linesRemovedChanged(numLinesRemoved);
        emit scoreChanged(score);

        timer.start(500, this);
        isWaitingAfterLine = true;
        curPiece.setShape(NoShape);
        update();
    }

}
//初始化新出现的方块
void TetrixBoard::newPiece()
{
    curPiece = nextPiece;
    nextPiece.setRandomShape();
    showNextPiece();
    curX = BoardWidth / 2 + 1;
    curY = BoardHeight - 1 + curPiece.minY();

    if (!tryMove(curPiece, curX, curY)) {
        curPiece.setShape(NoShape);
        timer.stop();
        isStarted = false;
    }

}

void TetrixBoard::showNextPiece()
{
    if (!nextPieceLabel)
        return;
    //用来设置下一个方块的坐标范围
    int dx = nextPiece.maxX() - nextPiece.minX() + 1;
    int dy = nextPiece.maxY() - nextPiece.minY() + 1;

    QPixmap pixmap(dx * squareWidth(), dy * squareHeight());
    QPainter painter(&pixmap);
    //将在接下来的要出现的方块中的剩余部分填充为背景色
    painter.fillRect(pixmap.rect(), nextPieceLabel->palette().background());

    for (int i = 0; i < 4; ++i) {
        int x = nextPiece.x(i) - nextPiece.minX();
        int y = nextPiece.y(i) - nextPiece.minY();
        drawSquare(painter, x * squareWidth(), y * squareHeight(),
                   nextPiece.shape());
    }
    nextPieceLabel->setPixmap(pixmap);

}

bool TetrixBoard::tryMove(const TetrixPiece &newPiece, int newX, int newY)
{
    for (int i = 0; i < 4; ++i) {
        int x = newX + newPiece.x(i);
        int y = newY - newPiece.y(i);
        if (x < 0 || x >= BoardWidth || y < 0 || y >= BoardHeight)
            return false;
        if (shapeAt(x, y) != NoShape)
            return false;
    }

    curPiece = newPiece;
    curX = newX;
    curY = newY;
    update();
    return true;
}


void TetrixBoard::drawSquare(QPainter &painter, int x, int y, TetrixShape shape)
{

    static const QRgb colorTable[8] = {
        0x000000, 0xCC6666, 0x66CC66, 0x6666CC,
        0xCCCC66, 0xCC66CC, 0x66CCCC, 0xDAAA00
    };
    painter.drawPixmap(x + 1, y + 1, squareWidth() - 3, squareHeight() - 3, QPixmap(":/box.gif"));

    QColor color = colorTable[int(shape)];

    //将颜色透明度减小到90
    color.setAlpha(90);

    painter.fillRect(x + 1, y + 1, squareWidth() - 2, squareHeight() - 2,color);

    //上部和左侧是亮色画线，下侧和右侧是暗色画线从而有一定立体感
    painter.setPen(color.light());
    painter.drawLine(x, y + squareHeight() - 1, x, y);
    painter.drawLine(x, y, x + squareWidth() - 1, y);

    painter.setPen(color.dark());
    painter.drawLine(x + 1, y + squareHeight() - 1,
                     x + squareWidth() - 1, y + squareHeight() - 1);
    painter.drawLine(x + squareWidth() - 1, y + squareHeight() - 1,
                     x + squareWidth() - 1, y + 1);
}
